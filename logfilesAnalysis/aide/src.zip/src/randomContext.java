import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import com.bt.lattice.run.ContextToLattice;
//import com.bt.lattice.run.LatticeEntropyExpt;


public class randomContext {

	/* random files for testing inf content stuff 
	 * This program generates a sequence of "runCount" random tables on a specified number of attributes and objects. 
	 * Proportion of 0/1 varies systematically.
	 * Each context is used to generate a lattice, then find the structural inf content and distribution entropy
	 * These are dumped to  output file fRes
	 */
	
	public static void main(String[] args) 
	{
//		System.out.println(",A1,A2,A3,A4,A5,A6");
		final int colCount=8;
		final int runCount = 1089;
		int rowCount=128;
		final int nBands=99;
	boolean randomConceptOcc=true;
	boolean randomConceptDist=true;
		Random rand = new Random();
		String f = "dump1";

		int bandCount=1;
		
		try
		{
			FileWriter fRes = new FileWriter("eOut1"+".csv");
		
		BufferedWriter bRes = new BufferedWriter(fRes);

for (int nRuns=0; nRuns < runCount; nRuns++)
{
	if(bandCount * (runCount/nBands) < nRuns) bandCount++;

		try
		{
			FileWriter fw = new FileWriter(f+".csv");
		
		BufferedWriter bw = new BufferedWriter(fw);
		for( int attr=0; attr < colCount; attr++)
			bw.write(",A"+attr);
		bw.write("\n");
	

	for (int i=0; i < rowCount; i++)
	
		{
		bw.write("o"+i);
			for (int j=0; j < colCount; j++)
			{	
/*			for(int k=0; k < 10000; k++)
				if(rand.nextInt(10)>4) counter++;
			
				System.out.print(","+counter);
				*/
				if(rand.nextInt(100)>bandCount)
					bw.write(",1");
				else
					bw.write(",0");
			}
			bw.write("\n");
		}
	
bw.flush();		
fw.close();
	ContextToLattice c = new ContextToLattice(f+".csv");
	switch(c.run())
	{
		case 1:
			System.err.println("file not found.\n");
			break;
		case 2:
			System.err.println("error while loading. Skipping...\n");
			break;
		case 3:
			System.err.println("error while saving.\n");
			break;
		default:
			// System.out.println("completed processing of " + f);

	}
//	LatticeEntropyExpt latEntExpt = new LatticeEntropyExpt(f+LatticeEntropyExpt.LATSUFFIX); //GroupRandomly()); // GroupBySize());
//	
//	
//	latEntExpt.outputEntropyStringsToBuffer(bRes);
	
		}
		catch (IOException e)
		{
			System.err.println("randomContextInner IOException:: " + e);	
		}
		System.out.println(	runCount + "/"+ nRuns);
	
}
bRes.flush();		
fRes.close();

	}
	catch (IOException e)
	{
		System.err.println("randomContextOuter IOException:: " + e);	
	}	
 
}
}
