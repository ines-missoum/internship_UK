package com.bt.lattice.run;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.bt.cost.DistanceCalculator;
import com.bt.lattice.Lattice;

import java.lang.Math;

public class TimedDistanceCalculator
{
	private static long loadingTime1=0;
	private static long loadingTime2=0;
	private static long matrixCreationTime;
	private static long hungarianTime;
	private static final String LATSUFFIX = ".lat";
	private static final boolean PRINTCOSTTABLE=false;
	private static final boolean PRINTINTENTS=false;
	private static final boolean PRINTEXTENTS=false;
	private static final boolean NORMALISETOMAXCOST=false;
	private static final boolean PRINTASSIGNMENT=false;
	private static int ASSIGNMENTTHRESHOLD=1000;

	public static void main(String[] args) throws IOException
	{
//		final String DIR = "/Users/entpm/eclipse code/fuzzy-edit-distance-12m/latticeData/";
//		final String DIR =  "/Users/entpm/eclipse code/fuzzy-edit-distance-12m/latticeData/";   //"/Users/entpm/BT code/cyberdata/";
//			final String DIR = "/Users/entpm/eclipse code/fuzzy-edit-distance-12m/latticeData/DistTests/"; 
		 final String DIR =  "/Users/entpm/eclipse code/latticeData/";
		boolean addDir = false;
		String[] INFILES = {


				"bName4m1",
				"bName4m2",
				"bName4m3",
		"bName4m4",
		"bName4m5",
		"bName4m6",
		"bName4m7",
		"bName4m8",
		"bName4m9",
		"bName4m10",
		"bName5m1",
		"bName5m2",
		"bName5m3",
	"bName5m4",
	"bName5m5",
	"bName5m6",
	"bName5m7",
	"bName5m8",
	"bName5m9",
	"bName5m10",
		"bName8m1",
		"bName8m2",
		"bName8m3",
	"bName8m4",
	"bName8m5",
	"bName8m6",
	"bName8m7",
	"bName8m8",
	"bName8m9",
	"bName8m10"
//				"eList4m1",
//				"eList4m2",
//				"eList4m3",
//				"eList4m4",
//		"eList4m5",
//		"eList4m6",
//		"eList4m7",
//		"eList4m8",
//		"eList4m9",
//		"eList4m10",
//		"eList5m1",
//		"eList5m2",
//		"eList5m3",
//		"eList5m4",
//	"eList5m5",
//	"eList5m6",
//	"eList5m7",
//	"eList5m8",
//	"eList5m9",
//	"eList5m10",
//		"eList8m1",
//		"eList8m2",
//		"eList8m3",
//		"eList8m4",
//	"eList8m5",
//	"eList8m6",
//	"eList8m7",
//	"eList8m8",
//	"eList8m9",
//	"eList8m10"

};
		//		String[] INFILES = {"EvSysL1", "EvSysL2a", "EvSysL2", "EvSysL3a", "EvSysL3"};

		//		String[] INFILES = {"r081","r082","r083","r084","r085","r086","r087","r088","r089","r0810","r0811","r0812"};
//		String[] INFILES = {"ukci4", "ukci5", "ukci6", "ukci7", "ukci8", "ukci4ex","ukci4exDUP","ukciNULL"};
	//	String[] INFILES = {    "fCas2005",	"fCas2006",	"fCas2007",	"fCas2008",	"fCas2009",	"fCas2010"
	//						,  "t2005",	"t2006",	"t2007",	"t2008",	"t2009",	"t2010"
	//						,  "w2005",	"w2006",	"w2007",	"w2008",	"w2009",	"w2010"
	//						} ; // {"ukci4", "ukci5", "ukci6", "ukci7", "ukciNULL"};
/*		String[] INFILES = {"fcl2010km2", "v1fcl2010km2", "fcl2010km3", "v1fcl2010km3", "fcl2010km4", "v1fcl2010km4", "fcl2010km5", "v1fcl2010km5",
				"fcl2010km6", "v1fcl2010km6", "fcl2010km7", "v1fcl2010km7", "fcl2010km8", "v1fcl2010km8", "fcl2010km9", "v1fcl2010km9",
				"fcl2010km10", "v1fcl2010km10", "fcl2010km11", "v1fcl2010km11", "fcl2010km12", "v1fcl2010km12", 
				"fcl2010km13", "v1fcl2010km13", "fcl2010km14", "v1fcl2010km14", "fcl2010km15", "v1fcl2010km15", "fcl2010km16", "v1fcl2010km16", 
				"fcl2010km17", "v1fcl2010km17", "fcl2010km18", "v1fcl2010km18", "fcl2010km19", "v1fcl2010km19",  
				"fcl2010km20", "v1fcl2010km20", "fcl2010"};
*/

//		String[] INFILES ={"accFSP", "accRGR" , "acc1830", "urspeed"}; //{   "t2005" , "t2006" , "t2007", "t2008", "t2009", "t2010"}	;
		// {"ukci1", "ukci2", "ukci3"};
		//{   "a10252005" ,  "a10252006" ,   "a10252007",  "a10252008"    , "a10252009"  , "a10252010", "fcl2005" ,  "fcl2006" ,   "fcl2007",  "fcl2008"    , "fcl2009"  , "fcl2010" };
		String[] fileList;
		List<Double> mus = null; // new List({1.0, 0.8, 0.6, 0.4, 0.2}); 

		if (args.length >=2)
		{
			fileList = args;
			addDir = true;

		}
		else
		{
			fileList = INFILES;
			addDir = true;
		}	
		double[] costToNull = new double[fileList.length];
		Lattice[] lats = new Lattice[fileList.length]; // l1, l2;
		long totalTime = System.currentTimeMillis();
	
		for(int i=0; i < fileList.length; i++)
			{
			String fName;
			if(addDir)
				fName = DIR+fileList[i] + LATSUFFIX;
			else
				fName = fileList[i];
			System.out.print("Loading " + fileList[i] + "...");
			loadingTime1 = System.currentTimeMillis();
			lats[i] = new Lattice(new File(fName));
			if( NORMALISETOMAXCOST)
			{
				costToNull[i] = lats[i].costToEmpty();
			}
			
			loadingTime1 = System.currentTimeMillis() - loadingTime1;
			System.out.println("done (" + lats[i].getConcepts().size() + " concepts in " + loadingTime1 / 1000.0 + "s).");
			}
		Double[][] theCosts = new Double[fileList.length] [fileList.length];
		

	for (int i = 0; i < fileList.length; i++) 
			
		{
		theCosts[i][i]= 0.0;
			for (int j = i+1; j < fileList.length; j++) 
			{

		System.out.print("creating cost matrix...");
		matrixCreationTime = System.currentTimeMillis();
		DistanceCalculator dc ;
		if(mus != null)
			dc = new DistanceCalculator(lats[i], lats[j], mus);
		else
			dc = new DistanceCalculator(lats[i], lats[j]);

		if(PRINTCOSTTABLE) System.out.print(" cost table \n" + dc.toStringWithIntents());
		
		matrixCreationTime = System.currentTimeMillis() - matrixCreationTime;
		System.out.println("done (" + matrixCreationTime / 1000.0 + "s).");

		System.out.print("Calculating distance...");
		hungarianTime = System.currentTimeMillis();
		 theCosts[i][j] = dc.calculateDistance(ASSIGNMENTTHRESHOLD>0);
		 if(ASSIGNMENTTHRESHOLD>0)
		 {
			 int[] assign=dc.getCachedAssignment();
			 for(int i1 = 0; i1 < assign.length; i1++ )
			 {
				 if(dc.getPairCost(i1,assign[i1]) >= ASSIGNMENTTHRESHOLD)
				 {
					 System.out.printf("%d -> %d (cost= %.3g) %s -> %s\n", i1 , assign[i1] , dc.getPairCost(i1,assign[i1]),
						 dc.getIndexedConceptIntent(1, i1), dc.getIndexedConceptIntent(2, assign[i1]));
//					 System.out.printf("(swapped :) %s -> %s\n",
//							 dc.getIndexedConceptIntent(2, i1), dc.getIndexedConceptIntent(1, assign[i1]));
				 }
			 }
		 }
			if( NORMALISETOMAXCOST)
			{
				double maxCost = costToNull[i] + costToNull[j] ; // java.lang.Math.max(costToNull[i], costToNull[j]);
				if (maxCost > 0) 
					theCosts[i][j] /= maxCost;
			}
			theCosts[j][i]= theCosts[i][j];

		hungarianTime = System.currentTimeMillis() - hungarianTime;
		System.out.println("done (" + hungarianTime / 1000.0 + "s).");

		System.out.println("distance between " + fileList[i] + " and " + fileList[j] + ": " + theCosts[i][j]);
		System.out.println("------------");
			}
		}
	
		totalTime = System.currentTimeMillis() - totalTime;
		System.out.println("total time: " + totalTime / 1000.0 + "s.");
		System.out.printf("\nCost matrix\n");
//		for (int i = 0; i < INFILES.length; i++) 
//			System.out.printf(", %s",INFILES[i]);
//		System.out.println();

		for (int i = 0; i < fileList.length; i++) 
		{
			System.out.printf("%15s\t", fileList[i]+"  ");
			for (int j = 0; j < fileList.length; j++) 
				if( NORMALISETOMAXCOST)
					System.out.printf("%4.2f\t", theCosts[i][j]);
				else
					System.out.printf("%4.1f\t", theCosts[i][j]);
			System.out.println();
		}
			
	}
}
