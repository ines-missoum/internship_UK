/**
 * 
 */
package com.bt.lattice.run;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.bt.cost.DistanceCalculator;
import com.bt.lattice.Concept;
import com.bt.lattice.Element;
import com.bt.lattice.Lattice;

/**
 * @author entpm
 *
 */
public class OrderKeyConcepts {

	/**
	 * @param args
	 * experimental algorithm to order elements according to max similarity to neighbour (where similarity = assoc in terms of attributes)
	 * Find FCA lattice. Mark lowest concept for each element (i.e. reduced labelling). 
	 * Start with the largest cardinality set = most similar; list all elements of this set (they should be equivalent, so list in any order). 
	 * Next, choose reduced concept that has highest association (or jaccard) with current concept; 
	 * list all its reduced elements. If 2 equal (non-zero) assocs then choose max card of reduced elements, 
	 * then go for arbitrary order. 
	 * If we get to a point where there are only zero assocs, choose arbitray next concept.
	 *	TPM July 2013
	 */

		private static long loadingTime1=0;
		private static long loadingTime2=0;
		private static long matrixCreationTime;
		private static long hungarianTime;
		private static final String LATSUFFIX = ".lat";
		private static final boolean PRINTCOSTTABLE=false;
		private static final boolean NORMALISETOMAXCOST=false;

		public static void main(String[] args) throws IOException
		{
			final String DIR =  "/Users/entpm/BT code/cyberdata/accessExpt/";
			boolean addDir = false;
			String[] INFILES = {  "proxJanDawgsFCA10", "proxJanDawgsFCA9", "proxJanDawgsFCA8", 
					"proxJanDawgsFCA7"
					 , "proxJanDawgsFCA6" , "proxJanDawgsFCA5", "proxJanDawgsFCA4", "proxJanDawgsFCA3", "proxJanDawgsFCA2",
					 "proxJanDawgsFCA1"
					};
			String[] fileList;

			if (args.length >=2)
				fileList = args;
			else
			{
				fileList = INFILES;
				addDir = true;
			}	
			Lattice[] lats = new Lattice[fileList.length]; // l1, l2;
			long totalTime = System.currentTimeMillis();
		
			for(int i=0; i < fileList.length; i++)
				{
				String fName;
				if(addDir)
					fName = DIR+fileList[i] + LATSUFFIX;
				else
					fName = fileList[i];
				System.out.print("Loading " + fileList[i] + "...");
				loadingTime1 = System.currentTimeMillis();
				lats[i] = new Lattice(new File(fName));
					
				loadingTime1 = System.currentTimeMillis() - loadingTime1;
				System.out.println("done (" + lats[i].getConcepts().size() + " concepts in " + loadingTime1 / 1000.0 + "s).");
				}			
// for each object, find the largest concept containing that object (its reduced labelling point), also store number of times each concept is selected
			// ASSUMING crisp at the moment
		for (int i = 0; i < fileList.length; i++) 
				
		{
			System.out.println("// checking lattice " + fileList[i]);
			Lattice theLat = lats[i];
			HashMap<Element,Concept> keyConcepts = new HashMap<Element,Concept>();
			HashMap<Concept,Integer> conceptUsed = new HashMap<Concept,Integer>();		// should be combined with prev hashmap
			HashMap<Concept,HashMap<Concept,Double>> assocs = new HashMap<Concept,HashMap<Concept,Double>>();		// could be combined with prev hashmaps

			for(Element theObj : theLat.getTopConcept().getExtent().getElements())
			{
//				System.out.println("keyConcept :: "+theObj.getName() + " searching ");
				for(Concept concept : theLat.getConcepts())
				{
					//		System.out.println("keyConcept search:: "+concept.getExtent().abbrevExtent(30) );
					if(concept.getExtent().getElements().contains(theObj))
					{
					//			System.out.println("keyConcept present:: init " + keyConcepts.containsKey(theObj));
/*		if(keyConcepts.containsKey(theObj))
			System.out.println("keyConcept saved card::" + keyConcepts.get(theObj).getExtent().cardinality() + " cf " +concept.getExtent().cardinality());
		else
			System.out.println("keyConcept not yet present::");
						 
*/						if((keyConcepts.containsKey(theObj)==false)
								|| (keyConcepts.get(theObj).getExtent().cardinality() > concept.getExtent().cardinality()))
							keyConcepts.put(theObj,  concept);
						if(conceptUsed.containsKey(concept)==false) conceptUsed.put(concept, 1);
					}

				}
				//System.out.println("keyConcept :: "+theObj.getName() + " found lowest in " + keyConcepts.get(theObj).getExtent());
			}



			HashMap<Concept,Integer> conceptFreq = new HashMap<Concept,Integer>();
//			HashMap<Concept,Element> conceptToEl = new HashMap<Concept,Element>();
			int maxFreq=0;
	//		boolean unique=true;
			Concept currentConcept=null;
			Element startEl =null;

			for(Element el : keyConcepts.keySet())
			{	
				Concept c = keyConcepts.get(el);
				if(conceptFreq.containsKey(c))
				{
					conceptFreq.put(c, new Integer(conceptFreq.get(c)+1));
					if(maxFreq < conceptFreq.get(c))
					{
						maxFreq = conceptFreq.get(c);
						currentConcept = c;
					}
//					else if(maxFreq == conceptFreq.get(c))
//						unique = false;
//
				}
				else
				{
					conceptFreq.put(c, new Integer(1));
					if(currentConcept==null) 
						{
						currentConcept = c;
						
					maxFreq=1;
						}
//					conceptToEl.put(c, el);
				}
			}
			
			System.out.println("int[] " + fileList[i] +"={ /* " + currentConcept + " */"); // + " maxFreq "+maxFreq);
			boolean firstElem=true;
			while((maxFreq > 0) && (currentConcept != null))
			{
				Iterator<Element> it = keyConcepts.keySet().iterator();
				Element el;
				while(it.hasNext() && (maxFreq > 0))
				{
					el = it.next();
					if(keyConcepts.get(el) == currentConcept) 
					{
						if(firstElem == false)
							System.out.print(", ");
						else
							firstElem=false;
						
						System.out.print(el.getName() );

					maxFreq--;
					}
						
				}
				conceptUsed.put(currentConcept, 0);
			
			Concept nextConcept = null;
			
			maxFreq=1;	// to start loop
//			while (nextConcept == null)
	//		{
				double maxAssoc = 0;
				Concept testAssoc = null;
				for(Element els : keyConcepts.keySet())
				{
					Concept c1 = keyConcepts.get(els);
					if((conceptUsed.containsKey(c1)) && (conceptUsed.get(c1).intValue() == 1))
					{
						double temp = currentConcept.getExtent().intersectionCard(c1.getExtent());
					
						if(temp > maxAssoc)
						{
							maxAssoc = temp;
							testAssoc = c1;
						
						}
					}
				}
				if(testAssoc != null)
					nextConcept = testAssoc;
				else
				{
					Iterator<Concept> it1=keyConcepts.values().iterator();
					while((it1.hasNext()) && (nextConcept == null))
					{	testAssoc = it1.next();
						if((conceptUsed.containsKey(testAssoc)) && (conceptUsed.get(testAssoc).intValue() == 1))
								nextConcept = testAssoc;
					
					}
				}
					
				
				currentConcept = nextConcept;
				if(currentConcept == null)
					maxFreq = 0;
				else
				maxFreq = conceptFreq.get(currentConcept);
					
//			}
				
					}
			System.out.println("};");	
				
			
			

			
		}
			totalTime = System.currentTimeMillis() - totalTime;
			System.out.println("total time: " + totalTime / 1000.0 + "s.");
//			for (int i = 0; i < INFILES.length; i++) 
//				System.out.printf(", %s",INFILES[i]);
//			System.out.println();

		
				
		}
	
public static double assoc(Concept c1, Concept c2)	// yes it should be somewhere else
{
	double ret = c1.getExtent().intersectionCard(c2.getExtent())/(c1.getExtent().cardinality());

return ret;
}
}
