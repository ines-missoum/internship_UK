package com.bt.lattice.run;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Random;

public class RandomDataMaker
{
	private int objectCount;
	private int attributeCount;
	private String[] objects;
	private String[] attributes;
	private double[][] table;
	private Random rand;

	public static final double[] DEFAULT_MUS = { 0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1 };

	public RandomDataMaker(int objCount, int attCount)
	{
		rand = new Random();
		objectCount = objCount;
		attributeCount = attCount;
		generateAttributes();
		generateObjects();
	}

	public void generateBooleanData()
	{
		table = new double[objectCount][attributeCount];

		for(int i = 0; i < objectCount; i++)
			for(int j = 0; j < attributeCount; j++)
				table[i][j] = rand.nextInt(2);
	}

	public void generateFuzzyData(double[] mus)
	{
		table = new double[objectCount][attributeCount];

		for(int i = 0; i < objectCount; i++)
			for(int j = 0; j < attributeCount; j++)
				table[i][j] = randomPick(mus);
	}

	public void writeToCsv(OutputStream out)
	{
		PrintStream w = new PrintStream(new BufferedOutputStream(out));

		for(String s : attributes)
			w.print("," + s);

		w.println();
		for(int i = 0; i < objectCount; i++)
		{
			w.print(objects[i]);
			for(double d : table[i])
				w.print("," + d);
			w.println();
		}
		w.flush();
	}

	private void generateAttributes()
	{
		attributes = new String[attributeCount];

		for(int i = 0; i < attributeCount; i++)
			attributes[i] = Integer.toString(i);
	}

	private void generateObjects()
	{
		objects = new String[objectCount];

		for(int i = 0; i < objectCount; i++)
			objects[i] = makeString(i);
	}

	private String makeString(int n)
	{
		if(n < 26)
			return Character.toString((char) ('a' + n));
		else
			return makeString(n / 26 - 1) + Character.toString((char) ('a' + n % 26));
	}

	private double randomPick(double[] mus)
	{
		return mus[rand.nextInt(mus.length)];
	}

	public static void main(String args[]) throws FileNotFoundException
	{
		if(args.length < 4)
			return;

		RandomDataMaker m = new RandomDataMaker(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
		if(args[2].equals("0"))
			m.generateBooleanData();
		else
		{
			double[] mus;

			if(args.length <= 4)
				mus = DEFAULT_MUS;
			else
			{
				mus = new double[args.length - 4];
				for(int i = 4; i < args.length; i++)
					mus[i - 4] = Double.parseDouble(args[i]);
			}

			m.generateFuzzyData(mus);
		}
		m.writeToCsv(new FileOutputStream(new File(args[3])));
	}
}
