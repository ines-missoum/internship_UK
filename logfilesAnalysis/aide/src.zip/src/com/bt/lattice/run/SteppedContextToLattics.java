package com.bt.lattice.run;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Collections;

import com.bt.context.Context;
//import com.bt.lattice.Extent;
import com.bt.lattice.Concept;
import com.bt.lattice.Lattice;

public class SteppedContextToLattics
{
	private String csv;
	private String rootName;
	private final String CSVSUFFIX = ".csv";
	private final String LATSUFFIX = ".lat";
	private long readingTime;
	private long creationTime;
	private long savingTime;
	private long fileTime;
	private static long totalTime;
	private final boolean silentMode=true;

	private final boolean printExtents=false;
	private final boolean printIntents=false;

	public SteppedContextToLattics(String csv)
	{
		if(csv.endsWith(CSVSUFFIX))
		{
			this.csv = csv;
			rootName = csv.substring(0,csv.length() - CSVSUFFIX.length());
		}
		else
		{
			this.csv = csv+CSVSUFFIX;
			rootName = csv;
		}
			
	}

	public int run()
	{
		fileTime = System.currentTimeMillis();

		if(!silentMode)
			System.out.print("reading context...");
		readingTime = System.currentTimeMillis();
		Context c;
		try
		{
			c = new Context(new File(csv));
		}
		catch(FileNotFoundException e)
		{
			return 1;
		}
		catch(IOException e)
		{
			return 2;
		}

		readingTime = System.currentTimeMillis() - readingTime;
		if(!silentMode)
			System.out.println("done (" + c.getObjects().length + " objects and " + c.getAttributes().length + " attributes in " + readingTime / 1000.0 + "s).");

		if(!silentMode)
			System.out.print("creating lattice...");
		creationTime = System.currentTimeMillis();
		Lattice l = new Lattice(c);
		creationTime = System.currentTimeMillis() - creationTime;
		if(!silentMode)
			System.out.println("done (" + l.getConcepts().size() + " concepts in " + creationTime / 1000.0 + "s).");

		if(!silentMode)
			System.out.print("saving...");
		savingTime = System.currentTimeMillis();
		try
		{
			l.save(new File(rootName + LATSUFFIX));
		}
		catch(IOException e)
		{
			return 3;
		}
		savingTime = System.currentTimeMillis() - savingTime;
		if(!silentMode)
			System.out.println("done (" + sizeToString(new File(rootName + LATSUFFIX).length()) + " in " + savingTime / 1000.0 + "s).");

		fileTime = System.currentTimeMillis() - fileTime;
		if(!silentMode)
			System.out.println(csv + " done in " + fileTime / 1000.0 + "s");

		if(printExtents || printIntents)
		{
		 for(Concept e : l.getConcepts())
		 {
			 if(printIntents)
				 System.out.println(e.getIntent());
			 if(printExtents)
				 System.out.println(e.getExtent());
			if(printExtents && printIntents)
				System.out.println("----");
		 }
	}
		return 0;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		 final String DIR =  "/Users/entpm/BT code/cyberdata/VASTChal2014MC2-20140430/";
		boolean addDir = false;
		Double[] alphas = {0.0,.2,.4,.6,.8,1.0};
//		String[] INFILES = {"EvSysL1", "EvSysL2a", "EvSysL2", "EvSysL3a", "EvSysL3"};
//		String[] INFILES = {"fcaent1", "fcaent2","fcaent3" , "fcaent4", "fcaent5" , "fcaent6", "fcaent7"};
		String[] INFILES = { "ccFCA1" };
//		String[] INFILES = {"wi08","sp08","su08","au08","wi09","sp09","su09","au09","wi10","sp10","su10","au10","sp10red"};
//		String[] INFILES = {"r081","r082","r083","r084","r085","r086","r087","r088","r089","r0810","r0811","r0812"};
//		String[] INFILES = {"fw08", "fp08", "fs08", "fa08", "fw09", "fp09", "fs09", "fa09", "fw10", "fp10", "fs10", "fa10"};

//		String[] INFILES = {"cw08", "cp08", "cs08", "ca08", "cw09", "cp09", "cs09", "ca09", "cw10", "cp10", "cs10", "ca10"};
		
		/* "proxJanDawgsFCA10", "proxJanDawgsFCA9", "proxJanDawgsFCA8", "proxJanDawgsFCA7",
				 "proxJanDawgsFCA6", "proxJanDawgsFCA5", "proxJanDawgsFCA4", "proxJanDawgsFCA3", "proxJanDawgsFCA2",
				 "proxJanDawgsFCA1" */ /*"acctran1130ur", "acctran1130ru",  "acctran1130b", */ 
		//{     "fCas2005",	"fCas2006",	"fCas2007",	"fCas2008",	"fCas2009",	"fCas2010"
			//	,  "uus2005",	"uus2006",	"uus2007",	"uus2008",	"uus2009",	"uus2010"
				//,  "urs2005",	"urs2006",	"urs2007",	"urs2008",	"urs2009",	"urs2010"} ; // {"ukci4", "ukci5", "ukci6", "ukci7", "ukciNULL"};
		// {"accFSP", "accRGR", "acc1830", "urspeed"};
//		String[] INFILES ={"accFSP", "accRGR", "acc1830", "urspeed"}; //{   "t2005" , "t2006" , "t2007", "t2008", "t2009", "t2010"}	;
//		String[] INFILES = {"EvSysL1", "ukci2", "ukci3"};
		//{   "a10252005" ,  "a10252006" ,   "a10252007",  "a10252008"    , "a10252009"  , "a10252010", "fcl2005" ,  "fcl2006" ,   "fcl2007",  "fcl2008"    , "fcl2009"  , "fcl2010" };
//		String[] INFILES = {"access24FCA"};	
//		String[] INFILES = {"a32010km2", "a32010km3","a32010km4", "a32010km5","a32010km6","a32010", "a32009"};
/*		String[] INFILES = {"a32010km2v0", "a32010km2v1", "a32010km2v2", "a32010km2v3", "a32010km2v4",
				"a32010km3v0", "a32010km3v1", "a32010km3v2", "a32010km3v3", "a32010km3v4",
				"a32010km4v0", "a32010km4v1", "a32010km4v2", "a32010km4v3", "a32010km4v4",
				"a32010km5v0", "a32010km5v1", "a32010km5v2", "a32010km5v3", "a32010km5v4",
				"a32010", "a32009"};
				*/
//		String[] INFILES = {"andreiEx"};
		/* {"fcl2010km10", "fcl2010km17", "fcl2010km5", "v1fcl2010km12", "v1fcl2010km19", "v1fcl2010km7",
				"fcl2010km11", "fcl2010km18", "fcl2010km6", "v1fcl2010km13", "v1fcl2010km2", "v1fcl2010km8",
				"fcl2010km12", "fcl2010km19", "fcl2010km7", "v1fcl2010km14", "v1fcl2010km20", "v1fcl2010km9",
				"fcl2010km13", "fcl2010km2", "fcl2010km8", "v1fcl2010km15", "v1fcl2010km3", "fcl2010km14",
				"fcl2010km20", "fcl2010km9", "v1fcl2010km16", "v1fcl2010km4", "fcl2010km15", "fcl2010km3", 
				"v1fcl2010km10",	"v1fcl2010km17", "v1fcl2010km5", "fcl2010km16", "fcl2010km4", 
				"v1fcl2010km11",	"v1fcl2010km18", "v1fcl2010km6"}; */
		String[] fileList;

		if (args.length >0)
		{
			fileList = args;
			addDir = false;
		}
		else
		{
			fileList = INFILES;
			addDir = true;
		}	
		totalTime = System.currentTimeMillis();
		for(String a : fileList)
		{
			String f;
			if(addDir) f = DIR+a;
			else
				f=a;
			System.out.println("\nprocessing " + a + "...");
			ContextToLattice c = new ContextToLattice(f+".csv");
			switch(c.run())
			{
				case 1:
					System.err.println("file not found.\n");
					break;
				case 2:
					System.err.println("error while loading. Skipping...\n");
					break;
				case 3:
					System.err.println("error while saving.\n");
					break;
				default:
					System.out.println("completed processing of " + a);

			}
		}

		totalTime = System.currentTimeMillis() - totalTime;

		if(fileList.length > 1)
			System.out.println("all files processed in " + totalTime / 1000.0 + "s.");
	}

	private static String sizeToString(long size)
	{
		StringWriter s = new StringWriter();
		PrintWriter p = new PrintWriter(s);

		if(size < 2048)
			p.print(size + " B");
		else if(size < 2048 * 1024)
			p.printf("%.2f kB", size / 1024.0);
		else
			p.printf("%.2f MB", size / (1024.0 * 1024.0));

		return s.toString();
	}
}

