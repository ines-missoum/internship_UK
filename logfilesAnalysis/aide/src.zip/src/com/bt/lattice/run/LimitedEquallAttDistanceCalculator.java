package com.bt.lattice.run;

	/*
	 * hack to find percentage-based distance between lattices with equal attributes. Hack in the sense that it is designed for the traffic/time/day-night
	 * example so assumes the only concepts to be compared are those with 2 attributes - valid in this case
	 */
	
	

	import java.io.File;
	import java.io.IOException;
import java.util.ArrayList;
	import java.util.List;

import com.bt.graphml.ConceptUtil;
import com.bt.graphml.PrintForMathematica;
import com.bt.lattice.Concept;
import com.bt.lattice.Intent;
import com.bt.lattice.Lattice;

	public class LimitedEquallAttDistanceCalculator 
	{
		private static long loadingTime1=0;
		private static long loadingTime2=0;
		private static long matrixCreationTime;
		private static long hungarianTime;
		private static final String LATSUFFIX = ".lat";
		private static final String MMASUFFIX = ".nb";
		private static final boolean PRINTCOSTTABLE=true;
		private static final boolean PRINTINTENTS=true;
		private static final boolean NORMALISETOMAXCOST=false;

		public static void main(String[] args) throws IOException
		{
			//			final String DIR = "/Users/entpm/eclipse code/fuzzy-edit-distance-12m/latticeData/";
			//			final String DIR =  "/Users/entpm/eclipse code/fuzzy-edit-distance-12m/latticeData/";   //"/Users/entpm/BT code/cyberdata/";
			//				final String DIR = "/Users/entpm/eclipse code/fuzzy-edit-distance-12m/latticeData/DistTests/"; 
			final String DIR =  "/Users/entpm/eclipse code/latticeData/"; ///Users/entpm/BT code/cyberdata/accessExpt/"; // "";
			boolean addDir = false;
			String[] INFILES = {"fw08", "fp08", "fs08", "fa08", "fw09", "fp09", "fs09", "fa09", "fw10", "fp10", "fs10", "fa10"};
			//			String[] INFILES = {"ukci4", "ukci5", "ukci6", "ukci7", "ukci8", "ukci4ex","ukci4exDUP","ukciNULL"};
			//	String[] INFILES = {    "fCas2005",	"fCas2006",	"fCas2007",	"fCas2008",	"fCas2009",	"fCas2010"
			//						,  "t2005",	"t2006",	"t2007",	"t2008",	"t2009",	"t2010"
			//						,  "w2005",	"w2006",	"w2007",	"w2008",	"w2009",	"w2010"
			//						} ; // {"ukci4", "ukci5", "ukci6", "ukci7", "ukciNULL"};
			/*		String[] INFILES = {"fcl2010km2", "v1fcl2010km2", "fcl2010km3", "v1fcl2010km3", "fcl2010km4", "v1fcl2010km4", "fcl2010km5", "v1fcl2010km5",
					"fcl2010km6", "v1fcl2010km6", "fcl2010km7", "v1fcl2010km7", "fcl2010km8", "v1fcl2010km8", "fcl2010km9", "v1fcl2010km9",
					"fcl2010km10", "v1fcl2010km10", "fcl2010km11", "v1fcl2010km11", "fcl2010km12", "v1fcl2010km12", 
					"fcl2010km13", "v1fcl2010km13", "fcl2010km14", "v1fcl2010km14", "fcl2010km15", "v1fcl2010km15", "fcl2010km16", "v1fcl2010km16", 
					"fcl2010km17", "v1fcl2010km17", "fcl2010km18", "v1fcl2010km18", "fcl2010km19", "v1fcl2010km19",  
					"fcl2010km20", "v1fcl2010km20", "fcl2010"};
			 */

			//			String[] INFILES ={"accFSP", "accRGR" , "acc1830", "urspeed"}; //{   "t2005" , "t2006" , "t2007", "t2008", "t2009", "t2010"}	;
			// {"ukci1", "ukci2", "ukci3"};
			//{   "a10252005" ,  "a10252006" ,   "a10252007",  "a10252008"    , "a10252009"  , "a10252010", "fcl2005" ,  "fcl2006" ,   "fcl2007",  "fcl2008"    , "fcl2009"  , "fcl2010" };
			String[] fileList;
			List<Double> mus = null;

			if (args.length >=2)
				fileList = args;
			else
			{
				fileList = INFILES;
				addDir = true;
			}	
			int[] totalObjCard = new int[fileList.length];
			Lattice[] lats = new Lattice[fileList.length]; // l1, l2;
			long totalTime = System.currentTimeMillis();

			for(int i=0; i < fileList.length; i++)
			{
				String fName;
				if(addDir)
					fName = DIR+fileList[i] + LATSUFFIX;
				else
					fName = fileList[i];
				System.out.print("Loading " + fileList[i] + "...");
				loadingTime1 = System.currentTimeMillis();
				lats[i] = new Lattice(new File(fName));
				totalObjCard[i] = lats[i].getObjects().length;


				loadingTime1 = System.currentTimeMillis() - loadingTime1;
				System.out.println("done (" + lats[i].getConcepts().size() + " concepts in " + loadingTime1 / 1000.0 + "s).");
			}
			
			
			Double[][] theCosts = new Double[fileList.length] [fileList.length];

			PrintForMathematica mmaPrinter=new PrintForMathematica(true,false,true);


			for (int i = 0; i < fileList.length; i++) 
			{
				mmaPrinter.mmaPrintToFile(DIR+fileList[i] + MMASUFFIX, ConceptUtil.makeLatticeDiagram(lats[i]), fileList[i]);
				theCosts[i][i]= 0.0;

				for (int j = i+1; j < fileList.length; j++) 
				{

					System.out.print("creating cost matrix...");
					matrixCreationTime = System.currentTimeMillis();
					//			DistanceCalculator dc ;
					//			if(mus != null)
					//				dc = new DistanceCalculator(lats[i], lats[j], mus);
					//			else
					//				dc = new DistanceCalculator(lats[i], lats[j]);

					//			if(PRINTCOSTTABLE) System.out.print(" cost table \n" + dc.toStringWithIntents());

					matrixCreationTime = System.currentTimeMillis() - matrixCreationTime;
					System.out.println("done (" + matrixCreationTime / 1000.0 + "s).");

					System.out.print("Calculating distance...");
					//			hungarianTime = System.currentTimeMillis();
					theCosts[i][j] = 0.0;

					ArrayList<Double> pairCost = new ArrayList<Double>();
					ArrayList<Intent> intentUnion = new ArrayList<Intent>();
						
					for(int concIndex1=0; concIndex1 < lats[i].getConcepts().size(); concIndex1++)
						/*********************88
						 * 			D O N ' T    T R Y   T H I S     A T     H O M E
						 * hard coded for road traffic / light - dark example - will fail in other cases 
						 * 
						 * ********************
						 */
						{
							if(lats[i].getConcepts().get(concIndex1).getIntent().size()==2)
								intentUnion.add(lats[i].getConcepts().get(concIndex1).getIntent());
						}
					
					for(int concIndex2=0; concIndex2 < lats[j].getConcepts().size(); concIndex2++)
					{
						Intent int2 = lats[j].getConcepts().get(concIndex2).getIntent();
						if(int2.size()==2)				/*************** A N D   H E R E **************/
							if(lats[i].getConceptByIntent(int2) == null)
								intentUnion.add(int2);
					}
					
					
					for(int concIndex1=0; concIndex1 < intentUnion.size(); concIndex1++)
					{
						Concept c1 = lats[i].getConceptByIntent(intentUnion.get(concIndex1));
						Concept c2 = lats[j].getConceptByIntent(intentUnion.get(concIndex1));

						/*********************88
						 * 			D O N ' T    T R Y   T H I S     A T     H O M E
						 * hard coded for road traffic / light - dark example - will fail in other cases 
						 * 
						 * ********************
						 */
						if(c1 != null)
						{
								if (c2 != null)
								{
									pairCost.add(concIndex1,java.lang.Math.abs(c1.getExtent().size()*1.0/totalObjCard[i]  - c2.getExtent().size()*1.0/totalObjCard[j]));
								}
								else
									pairCost.add(concIndex1,c1.getExtent().size()*1.0/totalObjCard[i]);
								
							}
						else
							pairCost.add(concIndex1,c2.getExtent().size()*1.0/totalObjCard[j]);

						theCosts[i][j] += pairCost.get(concIndex1);
						
						System.out.println("pair cost " + intentUnion.get(concIndex1) + " = " + pairCost.get(concIndex1));

						}

						theCosts[j][i]= theCosts[i][j];

						hungarianTime = System.currentTimeMillis() - hungarianTime;
						System.out.println("done (" + hungarianTime / 1000.0 + "s).");

						System.out.println("distance between " + fileList[i] + " and " + fileList[j] + ": " + theCosts[i][j]);
					}
				}

				totalTime = System.currentTimeMillis() - totalTime;
				System.out.println("total time: " + totalTime / 1000.0 + "s.");
				System.out.printf("\nCost matrix\n");
				//			for (int i = 0; i < INFILES.length; i++) 
				//				System.out.printf(", %s",INFILES[i]);
				//			System.out.println();
			

			for (int i = 0; i < INFILES.length; i++) 
			{
				System.out.printf("%15s\t", INFILES[i]+"  ");
				for (int j = 0; j < INFILES.length; j++) 
					if( NORMALISETOMAXCOST)
						System.out.printf("%4.2f\t", theCosts[i][j]);
					else
						System.out.printf("%4.2f\t", theCosts[i][j]);
				System.out.println();
			}

		}



}
