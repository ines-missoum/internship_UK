package com.bt.xmu;

public class InterpolatingMethod {

}
