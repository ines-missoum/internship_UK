package com.bt.xmu;

import java.util.ArrayList;
import java.util.List;


public class XmuFuzzyInterpolater {
	
		ArrayList<InterpolatingMethod> costs; //array of costs ordered by ascending memberships
		ArrayList<Double> alphas;				// array of membership levels 
		/**
		 * creates an empty bag
		 * O(n)
		 * 
		 * @param mus
		 */
		public XmuFuzzyInterpolater(List<Double> alphs)
		{
			alphas = new ArrayList<Double>(alphs);
		}



}
